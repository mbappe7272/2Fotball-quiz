const questions = [
    { question: "Hvem vant VM i 2018?", options: ["Brasil", "Frankrike", "Tyskland", "Argentina"], answer: "Frankrike" },
    { question: "Hvor mange spillere er på banen fra hvert lag i en fotballkamp?", options: ["9", "10", "11", "12"], answer: "11" },
    { question: "Hvilket land har vunnet flest VM-titler?", options: ["Tyskland", "Italia", "Brasil", "Argentina"], answer: "Brasil" },
    { question: "Hvem har scoret flest mål i Champions League-historien?", options: ["Cristiano Ronaldo", "Lionel Messi", "Robert Lewandowski", "Karim Benzema"], answer: "Cristiano Ronaldo" },
    { question: "Hva heter det største stadionet i England?", options: ["Wembley", "Old Trafford", "Etihad", "Anfield"], answer: "Wembley" }
];

// Generer 200 spørsmål ved å kopiere de 5 spørsmålene flere ganger
for (let i = 0; i < 39; i++) {
    questions.push(...questions);
}

let currentQuestion = 0;
let score = 0;
let timeLeft = 10;
let timer;

function loadQuestion() {
    if (currentQuestion >= questions.length) {
        document.body.innerHTML = `<h1>Quizen er ferdig!</h1><p>Du fikk ${score} poeng!</p>`;
        return;
    }

    document.getElementById("question").textContent = questions[currentQuestion].question;
    let optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";
    questions[currentQuestion].options.forEach(option => {
        let btn = document.createElement("button");
        btn.textContent = option;
        btn.onclick = () => checkAnswer(option);
        optionsDiv.appendChild(btn);
    });

    timeLeft = 10;
    document.getElementById("timer").textContent = `Tid igjen: ${timeLeft} sek`;
    clearInterval(timer);
    timer = setInterval(() => {
        timeLeft--;
        document.getElementById("timer").textContent = `Tid igjen: ${timeLeft} sek`;
        if (timeLeft === 0) {
            nextQuestion();
        }
    }, 1000);
}

function checkAnswer(answer) {
    if (answer === questions[currentQuestion].answer) {
        score += 10;
    }
    document.getElementById("score").textContent = `Poeng: ${score}`;
    nextQuestion();
}

function nextQuestion() {
    currentQuestion++;
    loadQuestion();
}

loadQuestion();
